
const feedbackForm = document.getElementById("feedbackForm");
const messageBox = document.getElementById("feedbackMessageBox");
const currentYear = document.getElementById("currentYear");

// Display the current year in the footer
if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
}

// Show a message to the customer
function showMessage(message, type) {
    messageBox.textContent = message;
    messageBox.className = "feedback-message " + type;
}

// Handle feedback form submission
if (feedbackForm) {
    feedbackForm.addEventListener("submit", function (event) {
        event.preventDefault();

        // Get customer details
        const customerName = document.getElementById("customerName").value.trim();
        const customerEmail = document.getElementById("customerEmail").value.trim();
        const bookingReference = document.getElementById("bookingReference").value.trim();
        const feedbackCategory = document.getElementById("feedbackCategory").value;
        const feedbackText = document.getElementById("feedbackMessage").value.trim();

        // Get the selected rating
        const selectedRating = document.querySelector(
            'input[name="rating"]:checked'
        );

        // Get the recommendation answer
        const selectedRecommendation = document.querySelector(
            'input[name="recommend"]:checked'
        );

        // Check that all required details are provided
        if (
            customerName === "" ||
            customerEmail === "" ||
            feedbackCategory === "" ||
            feedbackText === ""
        ) {
            showMessage("Please complete all required fields.", "error");
            return;
        }

        // Check the rating
        if (!selectedRating) {
            showMessage("Please select a rating for your journey.", "error");
            return;
        }

        // Check the recommendation answer
        if (!selectedRecommendation) {
            showMessage("Please select whether you recommend our service.", "error");
            return;
        }

        // Require a meaningful comment
        if (feedbackText.length < 10) {
            showMessage(
                "Please enter at least 10 characters in your comments.",
                "error"
            );
            return;
        }

        // Create a feedback record
        const feedback = {
            feedbackId: "FB" + Date.now(),
            customerName: customerName,
            customerEmail: customerEmail,
            bookingReference: bookingReference,
            category: feedbackCategory,
            rating: Number(selectedRating.value),
            comments: feedbackText,
            recommend: selectedRecommendation.value,
            submittedAt: new Date().toLocaleString()
        };

        // Get previously saved demo feedback
        let savedFeedback = [];

        try {
            const storedFeedback = localStorage.getItem("lankaMoveFeedback");

            if (storedFeedback) {
                savedFeedback = JSON.parse(storedFeedback);

                if (!Array.isArray(savedFeedback)) {
                    savedFeedback = [];
                }
            }
        } catch (error) {
            showMessage(
                "Unable to read saved feedback. Please try again.",
                "error"
            );
            return;
        }

        // Add the new feedback to the list
        savedFeedback.push(feedback);

        // Save feedback in the browser for this demonstration
        try {
            localStorage.setItem(
                "lankaMoveFeedback",
                JSON.stringify(savedFeedback)
            );
        } catch (error) {
            showMessage(
                "Feedback could not be saved in this browser.",
                "error"
            );
            return;
        }

        // Show confirmation
        showMessage(
            "Thank you, " + customerName +
            "! Your feedback has been recorded in this browser demo.",
            "success"
        );

        // Clear the form after successful submission
        feedbackForm.reset();

        // Bring the confirmation message into view
        messageBox.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });
    });
}

