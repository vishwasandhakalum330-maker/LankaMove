```javascript
// ============================================
// LankaMove Transport
// Book a Journey - JavaScript
// ============================================


// 1. Sample journey data
// These are demonstration values for coursework.
// Replace them with database data later.

const sampleJourneys = [
    {
        id: "J001",
        from: "Colombo",
        to: "Galle",
        busNumber: "LM-BUS-001",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "07:30 AM",
        arrival: "10:45 AM",
        duration: "3h 15m",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Galle Bus Station",
        price: 2300,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 18
    },
    {
        id: "J002",
        from: "Colombo",
        to: "Galle",
        busNumber: "LM-BUS-002",
        operator: "LankaMove Transport",
        busType: "Semi-Luxury Bus",
        departure: "09:00 AM",
        arrival: "12:30 PM",
        duration: "3h 30m",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Galle Bus Station",
        price: 2100,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 22
    },
    {
        id: "J003",
        from: "Colombo",
        to: "Matara",
        busNumber: "LM-BUS-003",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "08:00 AM",
        arrival: "12:00 PM",
        duration: "4h",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Matara Bus Station",
        price: 2600,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 16
    },
    {
        id: "J004",
        from: "Colombo",
        to: "Kandy",
        busNumber: "LM-BUS-004",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "06:30 AM",
        arrival: "10:00 AM",
        duration: "3h 30m",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Kandy Bus Station",
        price: 2000,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 20
    },
    {
        id: "J005",
        from: "Colombo",
        to: "Negombo",
        busNumber: "LM-BUS-005",
        operator: "LankaMove Transport",
        busType: "Standard Bus",
        departure: "09:30 AM",
        arrival: "11:00 AM",
        duration: "1h 30m",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Negombo Bus Station",
        price: 1200,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 25
    },
    {
        id: "J006",
        from: "Colombo",
        to: "Jaffna",
        busNumber: "LM-BUS-006",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "08:00 PM",
        arrival: "05:00 AM",
        duration: "9h",
        departureLocation: "Colombo Bus Terminal",
        arrivalLocation: "Jaffna Bus Station",
        price: 3800,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 12
    },
    {
        id: "J007",
        from: "Kandy",
        to: "Galle",
        busNumber: "LM-BUS-007",
        operator: "LankaMove Transport",
        busType: "Semi-Luxury Bus",
        departure: "07:00 AM",
        arrival: "12:00 PM",
        duration: "5h",
        departureLocation: "Kandy Bus Station",
        arrivalLocation: "Galle Bus Station",
        price: 2400,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 15
    },
    {
        id: "J008",
        from: "Galle",
        to: "Colombo",
        busNumber: "LM-BUS-008",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "02:00 PM",
        arrival: "05:15 PM",
        duration: "3h 15m",
        departureLocation: "Galle Bus Station",
        arrivalLocation: "Colombo Bus Terminal",
        price: 2300,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 18
    },
    {
        id: "J009",
        from: "Galle",
        to: "Matara",
        busNumber: "LM-BUS-009",
        operator: "LankaMove Transport",
        busType: "Standard Bus",
        departure: "10:00 AM",
        arrival: "11:15 AM",
        duration: "1h 15m",
        departureLocation: "Galle Bus Station",
        arrivalLocation: "Matara Bus Station",
        price: 1000,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 25
    }
];


// 2. Get page elements

const bookingForm = document.getElementById("bookingForm");
const confirmationMessage = document.getElementById("confirmationMessage");
const fareSection = document.querySelector(".fare-section");
const journeySection = document.querySelector(".journey-section");
const passengerSection = document.querySelector(".passenger-section");


// 3. Read the selected journey from Search Routes

function getSelectedJourney() {
    const savedJourney = sessionStorage.getItem("selectedJourney");

    if (savedJourney) {
        try {
            return JSON.parse(savedJourney);
        } catch (error) {
            console.error("Could not read the selected journey.", error);
        }
    }

    // Use a sample journey if the customer opens this page directly.
    return sampleJourneys[0];
}


// 4. Read the selected travel date and passenger count

function getBookingSearchDetails() {
    const savedDetails = sessionStorage.getItem("bookingSearchDetails");

    if (savedDetails) {
        try {
            return JSON.parse(savedDetails);
        } catch (error) {
            console.error("Could not read booking search details.", error);
        }
    }

    return {
        travelDate: "",
        passengers: 1
    };
}


// 5. Format prices in Sri Lankan rupees

function formatPrice(amount) {
    return "Rs. " + Number(amount).toLocaleString("en-LK", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


// 6. Format the travel date

function formatDate(dateValue) {
    if (!dateValue) {
        return "Not selected";
    }

    const date = new Date(dateValue + "T00:00:00");

    if (Number.isNaN(date.getTime())) {
        return "Not selected";
    }

    return date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}


// 7. Display the selected journey

function displayJourney() {
    const journey = getSelectedJourney();
    const searchDetails = getBookingSearchDetails();

    document.getElementById("busNumber").textContent =
        journey.busNumber || "Not available";

    document.getElementById("busOperator").textContent =
        journey.operator || "LankaMove Transport";

    document.getElementById("busType").textContent =
        journey.busType || "Standard Bus";

    document.getElementById("fromCity").textContent =
        journey.from || "Not available";

    document.getElementById("toCity").textContent =
        journey.to || "Not available";

    document.getElementById("departureTime").textContent =
        journey.departure || "--:--";

    document.getElementById("arrivalTime").textContent =
        journey.arrival || "--:--";

    document.getElementById("journeyDuration").textContent =
        journey.duration || "Not available";

    document.getElementById("durationDetails").textContent =
        journey.duration || "Not available";

    document.getElementById("departureLocation").textContent =
        journey.departureLocation ||
        journey.from + " Bus Station";

    document.getElementById("arrivalLocation").textContent =
        journey.arrivalLocation ||
        journey.to + " Bus Station";

    document.getElementById("travelDate").textContent =
        formatDate(searchDetails.travelDate);

    const passengers = Math.max(
        1,
        Number(searchDetails.passengers) || 1
    );

    document.getElementById("passengerCount").textContent =
        passengers + (passengers === 1 ? " Passenger" : " Passengers");

    document.getElementById("availableSeats").textContent =
        (journey.seats ?? 0) + " Seats";

    // Calculate the total fare.
    const ticketTotal = Number(journey.price || 0) * passengers;
    const bookingTotal = Number(journey.bookingFee || 0) * passengers;
    const serviceTotal = Number(journey.serviceCharge || 0) * passengers;

    const total = ticketTotal + bookingTotal + serviceTotal;

    document.getElementById("ticketFare").textContent =
        formatPrice(ticketTotal);

    document.getElementById("bookingFee").textContent =
        formatPrice(bookingTotal);

    document.getElementById("serviceCharge").textContent =
        formatPrice(serviceTotal);

    document.getElementById("totalFare").textContent =
        formatPrice(total);

    // Keep the selected values available for booking confirmation.
    return {
        journey: journey,
        passengers: passengers,
        travelDate: searchDetails.travelDate || "",
        ticketTotal: ticketTotal,
        bookingTotal: bookingTotal,
        serviceTotal: serviceTotal,
        total: total
    };
}


// 8. Create a booking reference

function createBookingReference() {
    const randomNumber = Math.floor(1000 + Math.random() * 9000);

    return "LM-" + new Date().getFullYear() + "-" + randomNumber;
}


// 9. Validate passenger information

function validatePassengerDetails() {
    const name = document.getElementById("passengerName").value.trim();
    const phone = document.getElementById("passengerPhone").value.trim();
    const email = document.getElementById("passengerEmail").value.trim();

    if (name.length < 3) {
        alert("Please enter the passenger's full name.");
        return false;
    }

    if (!/^0\d{9}$/.test(phone)) {
        alert("Please enter a valid Sri Lankan mobile number, for example 0771234567.");
        return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    return true;
}


// 10. Handle booking confirmation

bookingForm.addEventListener("submit", function (event) {
    event.preventDefault();

    if (!validatePassengerDetails()) {
        return;
    }

    const bookingDetails = displayJourney();
    const passengerName =
        document.getElementById("passengerName").value.trim();

    const passengerPhone =
        document.getElementById("passengerPhone").value.trim();

    const passengerEmail =
        document.getElementById("passengerEmail").value.trim();

    if (!bookingDetails.travelDate) {
        alert("Please return to Search Routes and select a travel date.");
        return;
    }

    if (bookingDetails.total <= 0) {
        alert("The journey fare is not valid. Please select another journey.");
        return;
    }

    const bookingReference = createBookingReference();

    // Save the booking for the payment page.
    const booking = {
        bookingReference: bookingReference,
        bookingStatus: "Pending Payment",
        paymentStatus: "Unpaid",

        passenger: {
            name: passengerName,
            phone: passengerPhone,
            email: passengerEmail
        },

        journey: {
            id: bookingDetails.journey.id,
            busNumber: bookingDetails.journey.busNumber,
            busType: bookingDetails.journey.busType,
            from: bookingDetails.journey.from,
            to: bookingDetails.journey.to,
            departure: bookingDetails.journey.departure,
            arrival: bookingDetails.journey.arrival,
            duration: bookingDetails.journey.duration,
            travelDate: bookingDetails.travelDate,
            passengers: bookingDetails.passengers
        },

        fare: {
            ticketFare: bookingDetails.ticketTotal,
            bookingFee: bookingDetails.bookingTotal,
            serviceCharge: bookingDetails.serviceTotal,
            total: bookingDetails.total
        },

        createdAt: new Date().toISOString()
    };

    // This is a frontend demonstration.
    // A real booking must be saved in the database.
    sessionStorage.setItem("currentBooking", JSON.stringify(booking));

    document.getElementById("bookingReference").textContent =
        bookingReference;

    // Hide the form and show the success message.
    journeySection.style.display = "none";
    passengerSection.style.display = "none";
    fareSection.style.display = "none";

    confirmationMessage.hidden = false;

    confirmationMessage.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });
});


// 11. Continue to the payment page

document.getElementById("continuePayment").addEventListener("click", function () {
    const booking = sessionStorage.getItem("currentBooking");

    if (!booking) {
        alert("Booking details could not be found. Please create your booking again.");
        return;
    }

    window.location.href = "payment.html";
});


// 12. Mobile sidebar menu

const menuButton = document.getElementById("menuButton");
const sidebar = document.getElementById("sidebar");

menuButton.addEventListener("click", function () {
    sidebar.classList.toggle("open");
});


// Close the sidebar when clicking outside it on mobile.
document.addEventListener("click", function (event) {
    if (
        window.innerWidth <= 950 &&
        sidebar.classList.contains("open") &&
        !sidebar.contains(event.target) &&
        !menuButton.contains(event.target)
    ) {
        sidebar.classList.remove("open");
    }
});


// 13. Set the current year in the footer

document.getElementById("currentYear").textContent =
    new Date().getFullYear();


// 14. Load the journey when the page opens

document.addEventListener("DOMContentLoaded", function () {
    displayJourney();
});
```
