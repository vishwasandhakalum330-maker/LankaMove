
document.addEventListener("DOMContentLoaded", function () {

   

    const menuButton = document.getElementById("menuButton");
    const closeMenu = document.getElementById("closeMenu");
    const sidebar = document.getElementById("sidebar");
    const sidebarOverlay = document.getElementById("sidebarOverlay");

    function openSidebar() {
        sidebar.classList.add("show");
        sidebarOverlay.classList.add("show");
    }

    function closeSidebar() {
        sidebar.classList.remove("show");
        sidebarOverlay.classList.remove("show");
    }

    if (menuButton) {
        menuButton.addEventListener("click", function () {
            openSidebar();
        });
    }

    if (closeMenu) {
        closeMenu.addEventListener("click", function () {
            closeSidebar();
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener("click", function () {
            closeSidebar();
        });
    }


    /* =========================================
       SIDEBAR NAVIGATION
       ========================================= */

    const navLinks = document.querySelectorAll(".nav-link");

    navLinks.forEach(function (link) {

        link.addEventListener("click", function () {

            navLinks.forEach(function (item) {
                item.classList.remove("active");
            });

            this.classList.add("active");

            closeSidebar();
        });

    });


    /* =========================================
       NOTIFICATION BUTTON
       ========================================= */

    const notificationButton =
        document.getElementById("notificationButton");

    if (notificationButton) {

        notificationButton.addEventListener("click", function () {

            alert(
                "You have 1 new notification.\n\n" +
                "Your upcoming Colombo to Galle journey is confirmed."
            );

        });

    }


    /* =========================================
       DASHBOARD CARD ANIMATION
       ========================================= */

    const dashboardCards =
        document.querySelectorAll(".dashboard-card");

    dashboardCards.forEach(function (card, index) {

        card.style.animationDelay = (index * 0.08) + "s";

    });


    /* =========================================
       STATISTICS ANIMATION
       ========================================= */

    const statCards =
        document.querySelectorAll(".stat-card");

    statCards.forEach(function (card, index) {

        card.style.animationDelay = (index * 0.1) + "s";

    });


    /* =========================================
       FIND YOUR JOURNEY BUTTON
       ========================================= */

    const journeyButton =
        document.querySelector(".primary-button");

    if (journeyButton) {

        journeyButton.addEventListener("click", function (event) {

            const routesSection =
                document.querySelector("#routes");

            if (routesSection) {

                event.preventDefault();

                routesSection.scrollIntoView({
                    behavior: "smooth"
                });

            } else {

                alert(
                    "Route search will be available here."
                );

            }

        });

    }


    /* =========================================
       DASHBOARD CARD CLICK
       ========================================= */

    dashboardCards.forEach(function (card) {

        card.addEventListener("click", function (event) {

            const target =
                card.getAttribute("href");

            if (!target || target === "#") {
                return;
            }

            const targetSection =
                document.querySelector(target);

            if (!targetSection) {

                event.preventDefault();

                const cardTitle =
                    card.querySelector("h3");

                if (cardTitle) {

                    alert(
                        cardTitle.textContent +
                        " section will be available here."
                    );

                }

            }

        });

    });


    /* =========================================
       WINDOW RESIZE
       ========================================= */

    window.addEventListener("resize", function () {

        if (window.innerWidth > 750) {
            closeSidebar();
        }

    });


    /* =========================================
       LOGOUT CONFIRMATION
       ========================================= */

    const logoutLink =
        document.querySelector(".logout-link");

    if (logoutLink) {

        logoutLink.addEventListener("click", function (event) {

            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );

            if (!confirmLogout) {
                event.preventDefault();
            }

        });

    }


    /* =========================================
       CURRENT YEAR
       ========================================= */

    const footer =
        document.querySelector(".dashboard-footer p");

    if (footer) {

        const currentYear =
            new Date().getFullYear();

        footer.innerHTML =
            "© " +
            currentYear +
            " LankaMove Transport. All Rights Reserved.";

    }


    /* =========================================
       WELCOME MESSAGE
       ========================================= */

    console.log(
        "LankaMove Customer Dashboard loaded successfully."
    );

});

