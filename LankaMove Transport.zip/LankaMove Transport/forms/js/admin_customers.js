
/* ==========================================
   LankaMove Transport
   Customer Management Dashboard
   ========================================== */

document.addEventListener("DOMContentLoaded", function () {

    // Get HTML elements
    const tableBody = document.getElementById("customersTableBody");
    const searchInput = document.getElementById("customerSearch");
    const statusFilter = document.getElementById("statusFilter");
    const resetButton = document.getElementById("resetFilters");

    const addCustomerBtn = document.getElementById("addCustomerBtn");
    const customerModal = document.getElementById("customerModal");
    const viewModal = document.getElementById("viewModal");

    const customerForm = document.getElementById("customerForm");
    const modalTitle = document.getElementById("modalTitle");

    const customerId = document.getElementById("customerId");
    const customerName = document.getElementById("customerName");
    const customerEmail = document.getElementById("customerEmail");
    const customerPhone = document.getElementById("customerPhone");
    const customerDate = document.getElementById("customerDate");
    const customerStatus = document.getElementById("customerStatus");

    const totalCustomers = document.getElementById("totalCustomers");
    const activeCustomers = document.getElementById("activeCustomers");
    const inactiveCustomers = document.getElementById("inactiveCustomers");
    const newCustomers = document.getElementById("newCustomers");

    const recordCount = document.getElementById("recordCount");
    const tableSummary = document.getElementById("tableSummary");
    const emptyState = document.getElementById("emptyState");

    const customerDetails = document.getElementById("customerDetails");

    const menuToggle = document.getElementById("menuToggle");
    const sidebar = document.getElementById("sidebar");

    // Demo data warning:
    // These records currently exist only in the browser.
    // They are not connected to Oracle Database.

    let nextCustomerNumber = 6;

    // ------------------------------------------
    // 1. Search and Filter Customers
    // ------------------------------------------

    function filterCustomers() {

        const searchText = searchInput.value
            .trim()
            .toLowerCase();

        const selectedStatus = statusFilter.value;

        const rows = tableBody.querySelectorAll("tr");
        let visibleCount = 0;

        rows.forEach(function (row) {

            const rowText = row.textContent.toLowerCase();
            const rowStatus = row.dataset.status;

            const matchesSearch = rowText.includes(searchText);

            const matchesStatus =
                selectedStatus === "all" ||
                rowStatus === selectedStatus;

            if (matchesSearch && matchesStatus) {
                row.hidden = false;
                visibleCount++;
            } else {
                row.hidden = true;
            }

        });

        // Update visible record information
        recordCount.textContent = visibleCount + " records";

        tableSummary.textContent =
            "Showing " + visibleCount + " customers";

        emptyState.hidden = visibleCount !== 0;
    }

    searchInput.addEventListener("input", filterCustomers);

    statusFilter.addEventListener("change", filterCustomers);

    resetButton.addEventListener("click", function () {

        searchInput.value = "";
        statusFilter.value = "all";

        filterCustomers();

    });

    // ------------------------------------------
    // 2. Update Customer Statistics
    // ------------------------------------------

    function updateStatistics() {

        const rows = Array.from(tableBody.querySelectorAll("tr"));

        let activeCount = 0;
        let inactiveCount = 0;
        let newCount = 0;

        const today = new Date();

        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();

        rows.forEach(function (row) {

            const status = row.dataset.status;

            if (status === "Active") {
                activeCount++;
            }

            if (status === "Inactive") {
                inactiveCount++;
            }

            // Read the registration date from the table
            const dateCell = row.cells[4];

            if (dateCell) {

                const registrationDate = new Date(
                    dateCell.dataset.date || ""
                );

                if (
                    !Number.isNaN(registrationDate.getTime()) &&
                    registrationDate.getMonth() === currentMonth &&
                    registrationDate.getFullYear() === currentYear
                ) {
                    newCount++;
                }
            }

        });

        totalCustomers.textContent = rows.length;
        activeCustomers.textContent = activeCount;
        inactiveCustomers.textContent = inactiveCount;
        newCustomers.textContent = newCount;
    }

    // ------------------------------------------
    // 3. Open Add Customer Form
    // ------------------------------------------

    function openAddModal() {

        customerForm.reset();

        customerId.value = "";

        modalTitle.textContent = "Add New Customer";

        customerStatus.value = "Active";

        customerDate.value = new Date().toISOString().slice(0, 10);

        customerModal.hidden = false;

        customerName.focus();
    }

    addCustomerBtn.addEventListener("click", openAddModal);

    // ------------------------------------------
    // 4. Close Modals
    // ------------------------------------------

    function closeCustomerModal() {
        customerModal.hidden = true;
    }

    function closeViewModal() {
        viewModal.hidden = true;
    }

    document.getElementById("closeModal")
        .addEventListener("click", closeCustomerModal);

    document.getElementById("cancelForm")
        .addEventListener("click", closeCustomerModal);

    document.getElementById("closeViewModal")
        .addEventListener("click", closeViewModal);

    document.getElementById("closeDetails")
        .addEventListener("click", closeViewModal);

    // Close a modal by clicking its background
    [customerModal, viewModal].forEach(function (modal) {

        modal.addEventListener("click", function (event) {

            if (event.target === modal) {
                modal.hidden = true;
            }

        });

    });

    // Close modals with the Escape key
    document.addEventListener("keydown", function (event) {

        if (event.key === "Escape") {
            closeCustomerModal();
            closeViewModal();
        }

    });

    // ------------------------------------------
    // 5. Generate Customer IDs
    // ------------------------------------------

    function generateCustomerId() {

        let newId;

        do {
            newId = "CUS" +
                String(nextCustomerNumber).padStart(3, "0");

            nextCustomerNumber++;

        } while (
            document.querySelector(
                '#customersTableBody tr[data-id="' + newId + '"]'
            )
        );

        return newId;
    }

    // ------------------------------------------
    // 6. Format Registration Date
    // ------------------------------------------

    function formatDate(dateString) {

        const parts = dateString.split("-");

        if (parts.length !== 3) {
            return dateString;
        }

        const date = new Date(
            Number(parts[0]),
            Number(parts[1]) - 1,
            Number(parts[2])
        );

        return date.toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    // ------------------------------------------
    // 7. Create Customer Table Row
    // ------------------------------------------

    function createCustomerRow(customer) {

        const row = document.createElement("tr");

        row.dataset.id = customer.id;
        row.dataset.status = customer.status;

        // Create customer identity
        const identityCell = document.createElement("td");

        const identity = document.createElement("div");
        identity.className = "customer-cell";

        const avatar = document.createElement("div");
        avatar.className = "customer-avatar";

        avatar.textContent = customer.name
            .split(/\s+/)
            .filter(Boolean)
            .slice(0, 2)
            .map(function (part) {
                return part.charAt(0).toUpperCase();
            })
            .join("");

        const identityInfo = document.createElement("div");

        const nameElement = document.createElement("strong");
        nameElement.textContent = customer.name;

        const description = document.createElement("span");
        description.textContent = "Registered passenger";

        identityInfo.append(nameElement, description);

        identity.append(avatar, identityInfo);

        identityCell.appendChild(identity);

        // Create other customer information
        const idCell = document.createElement("td");
        idCell.textContent = customer.id;

        const emailCell = document.createElement("td");
        emailCell.textContent = customer.email;

        const phoneCell = document.createElement("td");
        phoneCell.textContent = customer.phone;

        const dateCell = document.createElement("td");
        dateCell.textContent = formatDate(customer.date);
        dateCell.dataset.date = customer.date;

        // Create status label
        const statusCell = document.createElement("td");

        const statusLabel = document.createElement("span");

        statusLabel.className = "status " +
            (customer.status === "Active" ? "active" : "inactive");

        statusLabel.textContent = customer.status;

        statusCell.appendChild(statusLabel);

        // Create action buttons
        const actionsCell = document.createElement("td");

        const actions = document.createElement("div");
        actions.className = "action-buttons";

        const buttonDetails = [
            {
                action: "view",
                icon: "fa-eye",
                className: "view-btn",
                label: "View " + customer.name
            },
            {
                action: "edit",
                icon: "fa-pen",
                className: "edit-btn",
                label: "Edit " + customer.name
            },
            {
                action: "delete",
                icon: "fa-trash",
                className: "delete-btn",
                label: "Delete " + customer.name
            }
        ];

        buttonDetails.forEach(function (details) {

            const button = document.createElement("button");

            button.type = "button";
            button.className = "action-btn " + details.className;
            button.dataset.action = details.action;
            button.setAttribute("aria-label", details.label);

            const icon = document.createElement("i");

            icon.className = "fa-solid " + details.icon;

            button.appendChild(icon);
            actions.appendChild(button);

        });

        actionsCell.appendChild(actions);

        row.append(
            identityCell,
            idCell,
            emailCell,
            phoneCell,
            dateCell,
            statusCell,
            actionsCell
        );

        return row;
    }

    // ------------------------------------------
    // 8. Save a New Customer or Edit Existing One
    // ------------------------------------------

    customerForm.addEventListener("submit", function (event) {

        event.preventDefault();

        const name = customerName.value.trim();
        const email = customerEmail.value.trim();
        const phone = customerPhone.value.trim();
        const date = customerDate.value;
        const status = customerStatus.value;

        if (!name || !email || !phone || !date) {
            alert("Please complete all required fields.");
            return;
        }

        // Prevent duplicate email addresses
        const rows = Array.from(
            tableBody.querySelectorAll("tr")
        );

        const duplicateEmail = rows.some(function (row) {

            const rowEmail = row.cells[2].textContent.trim();

            return (
                rowEmail.toLowerCase() === email.toLowerCase() &&
                row.dataset.id !== customerId.value
            );

        });

        if (duplicateEmail) {
            alert("A customer with this email address already exists.");
            customerEmail.focus();
            return;
        }

        if (customerId.value) {

            // Edit existing customer
            const existingRow = rows.find(function (row) {
                return row.dataset.id === customerId.value;
            });

            if (!existingRow) {
                alert("Customer record not found.");
                return;
            }

            const updatedCustomer = {
                id: customerId.value,
                name: name,
                email: email,
                phone: phone,
                date: date,
                status: status
            };

            const updatedRow = createCustomerRow(updatedCustomer);

            existingRow.replaceWith(updatedRow);

            alert("Customer details updated successfully.");

        } else {

            // Add new customer
            const newCustomer = {
                id: generateCustomerId(),
                name: name,
                email: email,
                phone: phone,
                date: date,
                status: status
            };

            const newRow = createCustomerRow(newCustomer);

            tableBody.appendChild(newRow);

            alert("Customer added successfully.");
        }

        closeCustomerModal();

        filterCustomers();
        updateStatistics();

    });

    // ------------------------------------------
    // 9. Find Customer by ID
    // ------------------------------------------

    function findCustomerRow(id) {

        return Array.from(
            tableBody.querySelectorAll("tr")
        ).find(function (row) {
            return row.dataset.id === id;
        });
    }

    // ------------------------------------------
    // 10. View Customer Details
    // ------------------------------------------

    function viewCustomer(row) {

        const customer = {
            id: row.dataset.id,
            name: row.cells[0].querySelector("strong").textContent,
            email: row.cells[2].textContent,
            phone: row.cells[3].textContent,
            date: row.cells[4].textContent,
            status: row.dataset.status
        };

        customerDetails.replaceChildren();

        const detailList = document.createElement("div");
        detailList.className = "detail-list";

        const details = [
            ["Customer ID", customer.id],
            ["Full Name", customer.name],
            ["Email Address", customer.email],
            ["Phone Number", customer.phone],
            ["Registered Date", customer.date],
            ["Account Status", customer.status]
        ];

        details.forEach(function (detail) {

            const detailRow = document.createElement("div");
            detailRow.className = "detail-row";

            const label = document.createElement("span");
            label.textContent = detail[0];

            const value = document.createElement("strong");
            value.textContent = detail[1];

            detailRow.append(label, value);
            detailList.appendChild(detailRow);

        });

        customerDetails.appendChild(detailList);

        viewModal.hidden = false;
    }

    // ------------------------------------------
    // 11. Edit Customer
    // ------------------------------------------

    function editCustomer(row) {

        customerId.value = row.dataset.id;

        customerName.value =
            row.cells[0].querySelector("strong").textContent;

        customerEmail.value = row.cells[2].textContent;
        customerPhone.value = row.cells[3].textContent;

        // New rows store ISO dates in data-date.
        // Original demo rows need their displayed date converted.
        const storedDate = row.cells[4].dataset.date;

        customerDate.value = storedDate || convertDisplayDate(
            row.cells[4].textContent
        );

        customerStatus.value = row.dataset.status;

        modalTitle.textContent = "Edit Customer";

        customerModal.hidden = false;

        customerName.focus();
    }

    function convertDisplayDate(displayDate) {

        const parts = displayDate.trim().split(/\s+/);

        if (parts.length !== 3) {
            return "";
        }

        const months = {
            Jan: "01",
            Feb: "02",
            Mar: "03",
            Apr: "04",
            May: "05",
            Jun: "06",
            Jul: "07",
            Aug: "08",
            Sep: "09",
            Oct: "10",
            Nov: "11",
            Dec: "12"
        };

        const day = parts[0].padStart(2, "0");
        const month = months[parts[1]];
        const year = parts[2];

        if (!month || !/^\d{4}$/.test(year)) {
            return "";
        }

        return year + "-" + month + "-" + day;
    }

    // ------------------------------------------
    // 12. Delete Customer
    // ------------------------------------------

    function deleteCustomer(row) {

        const name =
            row.cells[0].querySelector("strong").textContent;

        const confirmed = window.confirm(
            "Are you sure you want to delete " + name + "?"
        );

        if (!confirmed) {
            return;
        }

        row.remove();

        filterCustomers();
        updateStatistics();

        alert("Customer removed from the demo table.");

    }

    // ------------------------------------------
    // 13. Handle Table Actions
    // ------------------------------------------

    tableBody.addEventListener("click", function (event) {

        const button = event.target.closest("button[data-action]");

        if (!button) {
            return;
        }

        const row = button.closest("tr");

        if (!row) {
            return;
        }

        const action = button.dataset.action;

        if (action === "view") {
            viewCustomer(row);
        }

        if (action === "edit") {
            editCustomer(row);
        }

        if (action === "delete") {
            deleteCustomer(row);
        }

    });

    // ------------------------------------------
    // 14. Mobile Sidebar
    // ------------------------------------------

    if (menuToggle && sidebar) {

        menuToggle.addEventListener("click", function () {
            sidebar.classList.toggle("open");
        });

        document.addEventListener("click", function (event) {

            if (
                window.innerWidth <= 900 &&
                sidebar.classList.contains("open") &&
                !sidebar.contains(event.target) &&
                !menuToggle.contains(event.target)
            ) {
                sidebar.classList.remove("open");
            }

        });

    }

    // ------------------------------------------
    // 15. Initial Setup
    // ------------------------------------------

    // Add ISO dates to the existing sample rows
    const initialDates = {
        CUS001: "2026-10-02",
        CUS002: "2026-10-04",
        CUS003: "2026-10-06",
        CUS004: "2026-10-08",
        CUS005: "2026-10-10"
    };

    tableBody.querySelectorAll("tr").forEach(function (row) {

        const dateCell = row.cells[4];

        if (initialDates[row.dataset.id]) {
            dateCell.dataset.date = initialDates[row.dataset.id];
        }

    });

    filterCustomers();
    updateStatistics();

});