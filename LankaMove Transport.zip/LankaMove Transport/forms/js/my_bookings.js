

function getBookings() {
    var savedData = localStorage.getItem("lankaMoveBookings");

    if (savedData === null) {
        return [];
    }

    try {
        var bookings = JSON.parse(savedData);
        return Array.isArray(bookings) ? bookings : [];
    } catch (error) {
        console.log("Unable to read booking information.");
        return [];
    }
}

function formatDate(dateValue) {
    if (!dateValue) {
        return "Date not available";
    }

    var date = new Date(dateValue + "T00:00:00");

    if (isNaN(date.getTime())) {
        return dateValue;
    }

    return date.toLocaleDateString("en-GB", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric"
    });
}

function formatPrice(amount) {
    var price = Number(amount);

    if (isNaN(price)) {
        price = 0;
    }

    return "Rs. " + price.toLocaleString("en-LK", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function getToday() {
    var now = new Date();
    var year = now.getFullYear();
    var month = String(now.getMonth() + 1).padStart(2, "0");
    var day = String(now.getDate()).padStart(2, "0");

    return year + "-" + month + "-" + day;
}

// Create a clear journey information card.
function createJourneyCard(booking) {
    var journey = booking.journey || {};

    var travelDate = booking.travelDate || "";
    var today = getToday();

    var journeyLabel = "Upcoming Journey";
    var cardClass = "booking-card";

    if (travelDate === today) {
        journeyLabel = "Your Journey Is Today!";
        cardClass += " today-booking";
    } else if (travelDate && travelDate < today) {
        journeyLabel = "Past Journey";
        cardClass += " past-booking";
    }

    var card = document.createElement("div");
    card.className = cardClass;

    function addText(parent, tag, className, text) {
        var element = document.createElement(tag);
        element.className = className;
        element.textContent = text;
        parent.appendChild(element);
        return element;
    }

    // Journey heading
    var heading = document.createElement("div");
    heading.className = "booking-top";

    var headingInfo = document.createElement("div");

    addText(
        headingInfo,
        "h2",
        "journey-title",
        (journey.from || "Departure") + " to " +
        (journey.to || "Destination")
    );

    addText(
        headingInfo,
        "p",
        "reference",
        "Booking Reference: " + (booking.reference || "Not available")
    );

    addText(
        headingInfo,
        "p",
        "journey-label",
        journeyLabel
    );

    heading.appendChild(headingInfo);

    var paymentStatus = booking.paymentStatus || "Unpaid";

    var status = addText(
        heading,
        "span",
        "status",
        paymentStatus
    );

    if (paymentStatus.toLowerCase() === "paid") {
        status.className = "status paid";
    }

    card.appendChild(heading);

    // Important travel date and time information
    var travelInfo = document.createElement("div");
    travelInfo.className = "travel-info";

    addText(
        travelInfo,
        "h3",
        "travel-date",
        "Travel Date: " + formatDate(travelDate)
    );

    var times = document.createElement("div");
    times.className = "travel-times";

    var departure = document.createElement("div");
    departure.className = "time-detail";

    addText(departure, "small", "", "DEPARTURE");
    addText(
        departure,
        "h3",
        "",
        journey.departureTime || "Time not available"
    );
    addText(
        departure,
        "p",
        "",
        journey.from || "Departure location unavailable"
    );

    var arrival = document.createElement("div");
    arrival.className = "time-detail";

    addText(arrival, "small", "", "ARRIVAL");
    addText(
        arrival,
        "h3",
        "",
        journey.arrivalTime || "Time not available"
    );
    addText(
        arrival,
        "p",
        "",
        journey.to || "Arrival location unavailable"
    );

    times.appendChild(departure);
    times.appendChild(arrival);
    travelInfo.appendChild(times);
    card.appendChild(travelInfo);

    // Bus and passenger information
    var details = document.createElement("div");
    details.className = "booking-details";

    var information = [
        ["Bus Number", journey.busNumber || "Not available"],
        ["Bus Type", journey.busType || "Not available"],
        ["Operator", journey.busOperator || "Not available"],
        ["Duration", journey.duration || "Not available"],
        ["Passenger Name", booking.passengerName || "Not available"],
        ["Passengers", booking.passengers || 1],
        ["Phone", booking.passengerPhone || "Not available"],
        ["Email", booking.passengerEmail || "Not available"]
    ];

    for (var i = 0; i < information.length; i++) {
        var detail = document.createElement("div");
        detail.className = "detail";

        addText(detail, "small", "", information[i][0]);
        addText(detail, "strong", "", information[i][1]);

        details.appendChild(detail);
    }

    card.appendChild(details);

    // Fare information
    var fare = document.createElement("div");
    fare.className = "fare-row";

    addText(
        fare,
        "h3",
        "",
        "Total Fare: " + formatPrice(booking.totalFare)
    );

    card.appendChild(fare);

    return card;
}

// Show all bookings, with upcoming journeys first.
function displayBookings() {
    var bookings = getBookings();

    var list = document.getElementById("bookingsList");
    var total = document.getElementById("totalBookings");
    var pending = document.getElementById("pendingBookings");
    var paid = document.getElementById("paidBookings");

    if (!list) {
        console.log("The bookingsList element was not found.");
        return;
    }

    if (total) {
        total.textContent = bookings.length;
    }

    var pendingCount = 0;
    var paidCount = 0;

    for (var i = 0; i < bookings.length; i++) {
        var payment = bookings[i].paymentStatus || "Unpaid";

        if (payment.toLowerCase() === "paid") {
            paidCount++;
        } else {
            pendingCount++;
        }
    }

    if (pending) {
        pending.textContent = pendingCount;
    }

    if (paid) {
        paid.textContent = paidCount;
    }

    // Sort upcoming journeys first, then today's and past journeys.
    bookings.sort(function (a, b) {
        var dateA = a.travelDate || "9999-12-31";
        var dateB = b.travelDate || "9999-12-31";

        return dateA.localeCompare(dateB);
    });

    list.innerHTML = "";

    if (bookings.length === 0) {
        var empty = document.createElement("div");
        empty.className = "empty-state";

        var title = document.createElement("h2");
        title.textContent = "No Booked Journeys Yet";

        var message = document.createElement("p");
        message.textContent =
            "When you book a bus journey, its date, time and travel details will appear here.";

        var button = document.createElement("a");
        button.href = "search_routes.html";
        button.className = "button";
        button.textContent = "Find a Bus Journey";

        empty.appendChild(title);
        empty.appendChild(message);
        empty.appendChild(button);

        list.appendChild(empty);
        return;
    }

    for (var j = 0; j < bookings.length; j++) {
        list.appendChild(createJourneyCard(bookings[j]));
    }
}

// Footer year
var yearElement = document.getElementById("currentYear");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}

// Load the customer's journeys.
displayBookings();
