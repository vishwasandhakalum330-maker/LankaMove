
var journeys = [
    {
        id: "J001",
        from: "Colombo",
        to: "Galle",
        busNumber: "LM-BUS-001",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "07:30 AM",
        arrival: "10:45 AM",
        duration: "3 hours 15 minutes",
        price: 2300,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 18
    },
    {
        id: "J002",
        from: "Colombo",
        to: "Galle",
        busNumber: "LM-BUS-002",
        operator: "LankaMove Transport",
        busType: "Semi-Luxury Bus",
        departure: "09:00 AM",
        arrival: "12:30 PM",
        duration: "3 hours 30 minutes",
        price: 2100,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 22
    },
    {
        id: "J003",
        from: "Colombo",
        to: "Kandy",
        busNumber: "LM-BUS-003",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "06:30 AM",
        arrival: "10:00 AM",
        duration: "3 hours 30 minutes",
        price: 2000,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 20
    },
    {
        id: "J004",
        from: "Colombo",
        to: "Matara",
        busNumber: "LM-BUS-004",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "08:00 AM",
        arrival: "12:00 PM",
        duration: "4 hours",
        price: 2600,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 16
    },
    {
        id: "J005",
        from: "Galle",
        to: "Colombo",
        busNumber: "LM-BUS-005",
        operator: "LankaMove Transport",
        busType: "Semi-Luxury Bus",
        departure: "02:00 PM",
        arrival: "05:30 PM",
        duration: "3 hours 30 minutes",
        price: 2100,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 22
    },
    {
        id: "J006",
        from: "Colombo",
        to: "Negombo",
        busNumber: "LM-BUS-006",
        operator: "LankaMove Transport",
        busType: "Normal Bus",
        departure: "10:00 AM",
        arrival: "11:30 AM",
        duration: "1 hour 30 minutes",
        price: 1200,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 30
    },
    {
        id: "J007",
        from: "Colombo",
        to: "Jaffna",
        busNumber: "LM-BUS-007",
        operator: "LankaMove Transport",
        busType: "Luxury AC Bus",
        departure: "08:00 PM",
        arrival: "05:00 AM",
        duration: "9 hours",
        price: 3800,
        bookingFee: 100,
        serviceCharge: 50,
        seats: 15
    }
];

// Get HTML elements
var searchForm = document.getElementById("routeSearchForm");
var fromSelect = document.getElementById("from");
var toSelect = document.getElementById("to");
var travelDateInput = document.getElementById("travelDate");
var passengersSelect = document.getElementById("passengers");

var resultsSection = document.getElementById("resultsSection");
var resultDescription = document.getElementById("resultDescription");
var resultCount = document.getElementById("resultCount");
var journeyResults = document.getElementById("journeyResults");
var formMessage = document.getElementById("formMessage");
var swapButton = document.getElementById("swapButton");
var currentYear = document.getElementById("currentYear");

// Get today's date
function getTodayDate() {
    var today = new Date();
    var year = today.getFullYear();
    var month = String(today.getMonth() + 1).padStart(2, "0");
    var day = String(today.getDate()).padStart(2, "0");

    return year + "-" + month + "-" + day;
}

// Format money
function formatPrice(amount) {
    return "Rs. " + Number(amount).toLocaleString("en-LK", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Format date
function formatDate(dateValue) {
    var date = new Date(dateValue + "T00:00:00");

    return date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

// Show matching journeys
function displayJourneys(matchingJourneys, travelDate, passengers) {
    journeyResults.innerHTML = "";
    resultsSection.hidden = false;

    resultDescription.textContent =
        fromSelect.value + " to " + toSelect.value +
        " | " + formatDate(travelDate) +
        " | " + passengers + " passenger(s)";

    resultCount.textContent =
        matchingJourneys.length + " bus(es) found";

    if (matchingJourneys.length === 0) {
        journeyResults.innerHTML =
            "<div class='empty-state'>" +
            "<h3>No buses found</h3>" +
            "<p>Please try another route.</p>" +
            "</div>";
        return;
    }

    matchingJourneys.forEach(function (journey) {
        var ticketTotal = journey.price * passengers;
        var bookingTotal = journey.bookingFee * passengers;
        var serviceTotal = journey.serviceCharge * passengers;
        var total = ticketTotal + bookingTotal + serviceTotal;

        var card = document.createElement("article");
        card.className = "journey-card";

        var details =
            "<h3>" + journey.from + " to " + journey.to + "</h3>" +
            "<p><strong>Bus:</strong> " + journey.busNumber + "</p>" +
            "<p><strong>Operator:</strong> " + journey.operator + "</p>" +
            "<p><strong>Bus type:</strong> " + journey.busType + "</p>" +
            "<p><strong>Departure:</strong> " + journey.departure + "</p>" +
            "<p><strong>Arrival:</strong> " + journey.arrival + "</p>" +
            "<p><strong>Duration:</strong> " + journey.duration + "</p>" +
            "<p><strong>Travel date:</strong> " + formatDate(travelDate) + "</p>" +
            "<p><strong>Available seats:</strong> " + journey.seats + "</p>" +
            "<hr>" +
            "<p>Ticket fare: " + formatPrice(ticketTotal) + "</p>" +
            "<p>Booking fee: " + formatPrice(bookingTotal) + "</p>" +
            "<p>Service charge: " + formatPrice(serviceTotal) + "</p>" +
            "<h3>Total: " + formatPrice(total) + "</h3>" +
            "<button type='button' class='select-journey'>" +
            "Select This Bus</button>";

        card.innerHTML = details;

        var selectButton = card.querySelector(".select-journey");

        selectButton.addEventListener("click", function () {
            var searchDetails = {
                from: journey.from,
                to: journey.to,
                travelDate: travelDate,
                passengers: passengers
            };

            sessionStorage.setItem(
                "selectedJourney",
                JSON.stringify(journey)
            );

            sessionStorage.setItem(
                "bookingSearchDetails",
                JSON.stringify(searchDetails)
            );

            window.location.href = "book_journey.html";
        });

        journeyResults.appendChild(card);
    });
}

// Search form
function searchJourneys(event) {
    event.preventDefault();

    formMessage.textContent = "";

    var from = fromSelect.value;
    var to = toSelect.value;
    var travelDate = travelDateInput.value;
    var passengers = Number(passengersSelect.value);

    if (from === "" || to === "" || travelDate === "") {
        formMessage.textContent =
            "Please complete all search fields.";
        return;
    }

    if (from === to) {
        formMessage.textContent =
            "Please select different starting and destination cities.";
        return;
    }

    if (travelDate < getTodayDate()) {
        formMessage.textContent =
            "Please choose today or a future date.";
        return;
    }

    if (
        !Number.isInteger(passengers) ||
        passengers < 1
    ) {
        formMessage.textContent =
            "Please select a valid number of passengers.";
        return;
    }

    var matchingJourneys = journeys.filter(function (journey) {
        return journey.from === from && journey.to === to;
    });

    displayJourneys(matchingJourneys, travelDate, passengers);
}

// Swap cities
if (swapButton) {
    swapButton.addEventListener("click", function () {
        var oldFrom = fromSelect.value;

        fromSelect.value = toSelect.value;
        toSelect.value = oldFrom;
    });
}

// Connect the form if it exists
if (searchForm) {
    searchForm.addEventListener("submit", searchJourneys);
}

// Set the earliest travel date
if (travelDateInput) {
    travelDateInput.min = getTodayDate();
}

// Hide results before searching
if (resultsSection) {
    resultsSection.hidden = true;
}

// Show current year
if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
}

