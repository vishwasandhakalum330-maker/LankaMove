// ========================================
// LankaMove Transport
// Main JavaScript
// ========================================

// Mobile menu
const menuButton = document.querySelector("#menuButton");
const navigation = document.querySelector("#navigation");

if (menuButton && navigation) {
    menuButton.addEventListener("click", function () {
        navigation.classList.toggle("show");
    });
}


// Set today's date as the minimum travel date
const travelDate = document.querySelector("#travelDate");

if (travelDate) {
    const today = new Date();

    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    travelDate.min = year + "-" + month + "-" + day;
}


// Swap From and To locations
const swapButton = document.querySelector("#swapButton");

if (swapButton) {
    swapButton.addEventListener("click", function () {

        const from = document.querySelector("#from");
        const to = document.querySelector("#to");

        if (from && to) {
            const temporary = from.value;

            from.value = to.value;
            to.value = temporary;
        }
    });
}


// Route form validation
const routeForm = document.querySelector("#routeForm");

if (routeForm) {
    routeForm.addEventListener("submit", function (event) {

        const from = document.querySelector("#from");
        const to = document.querySelector("#to");
        const date = document.querySelector("#travelDate");


        if (from.value === "") {
            event.preventDefault();

            alert("Please select your starting point.");
            from.focus();

            return;
        }


        if (to.value === "") {
            event.preventDefault();

            alert("Please select your destination.");
            to.focus();

            return;
        }


        if (from.value === to.value) {
            event.preventDefault();

            alert("Starting point and destination cannot be the same.");
            to.focus();

            return;
        }


        if (date.value === "") {
            event.preventDefault();

            alert("Please select your travel date.");
            date.focus();

            return;
        }

        alert(
            "Searching routes from " +
            from.value +
            " to " +
            to.value +
            "..."
        );
    });
}


// Close mobile menu after selecting a page
const navigationLinks = document.querySelectorAll(".navigation a");

navigationLinks.forEach(function (link) {

    link.addEventListener("click", function () {

        if (navigation) {
            navigation.classList.remove("show");
        }

    });

});