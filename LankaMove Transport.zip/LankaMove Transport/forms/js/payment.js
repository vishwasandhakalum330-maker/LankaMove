

var currentBooking = null;

// Get the booking selected by the customer
function loadCurrentBooking() {
    try {
        var savedBooking = sessionStorage.getItem("currentBooking");

        if (savedBooking) {
            currentBooking = JSON.parse(savedBooking);
            return currentBooking;
        }
    } catch (error) {
        console.log("Unable to load the current booking.");
    }

    return null;
}

// Format prices in Sri Lankan Rupees
function formatPrice(amount) {
    var price = Number(amount);

    if (isNaN(price)) {
        price = 0;
    }

    return "Rs. " + price.toLocaleString("en-LK", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Format the travel date
function formatTravelDate(dateValue) {
    if (!dateValue) {
        return "Date not available";
    }

    var date = new Date(dateValue + "T00:00:00");

    if (isNaN(date.getTime())) {
        return dateValue;
    }

    return date.toLocaleDateString("en-GB", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

// Display the booking details
function displayBookingDetails() {
    if (!currentBooking) {
        showMessage(
            "No current booking was found. Please book a journey first.",
            "error"
        );

        var button = document.getElementById("payButton");

        if (button) {
            button.disabled = true;
            button.textContent = "No Booking Available";
        }

        return;
    }

    var journey = currentBooking.journey || {};

    setText("bookingReference", currentBooking.reference || "Not available");
    setText("fromCity", journey.from || "Not available");
    setText("toCity", journey.to || "Not available");
    setText("departureTime", journey.departureTime || "Not available");
    setText("arrivalTime", journey.arrivalTime || "Not available");
    setText("travelDate", formatTravelDate(currentBooking.travelDate));
    setText("busNumber", journey.busNumber || "Not available");
    setText("busType", journey.busType || "Not available");
    setText("passengerCount", currentBooking.passengers || 1);

    setText("ticketFare", formatPrice(currentBooking.ticketFare));
    setText("bookingFee", formatPrice(currentBooking.bookingFee));
    setText("serviceCharge", formatPrice(currentBooking.serviceCharge));
    setText("totalFare", formatPrice(currentBooking.totalFare));

    // Do not pay for a booking that is already marked as paid.
    if (String(currentBooking.paymentStatus).toLowerCase() === "paid") {
        var payButton = document.getElementById("payButton");

        if (payButton) {
            payButton.disabled = true;
            payButton.textContent = "Already Paid";
        }

        showMessage("This booking has already been paid.", "success");
    }
}

// Set text safely
function setText(elementId, value) {
    var element = document.getElementById(elementId);

    if (element) {
        element.textContent = value;
    }
}

// Display a message
function showMessage(message, type) {
    var messageBox = document.getElementById("paymentMessage");

    if (!messageBox) {
        return;
    }

    messageBox.textContent = message;
    messageBox.className = "payment-message " + type;
}

// Show the selected payment method's details
function changePaymentMethod() {
    var selectedMethod = document.querySelector(
        'input[name="paymentMethod"]:checked'
    );

    var cardDetails = document.getElementById("cardDetails");
    var bankDetails = document.getElementById("bankDetails");
    var counterDetails = document.getElementById("counterDetails");

    var cardName = document.getElementById("cardName");
    var cardNumber = document.getElementById("cardNumber");
    var expiryDate = document.getElementById("expiryDate");
    var cvv = document.getElementById("cvv");

    if (!selectedMethod) {
        return;
    }

    var method = selectedMethod.value;

    if (cardDetails) {
        cardDetails.hidden = method !== "card";
    }

    if (bankDetails) {
        bankDetails.hidden = method !== "bank";
    }

    if (counterDetails) {
        counterDetails.hidden = method !== "counter";
    }

    // Only card payments require the demo card fields.
    if (cardName) {
        cardName.required = method === "card";
    }

    if (cardNumber) {
        cardNumber.required = method === "card";
    }

    if (expiryDate) {
        expiryDate.required = method === "card";
    }

    if (cvv) {
        cvv.required = method === "card";
    }

    var payButton = document.getElementById("payButton");

    if (payButton) {
        if (method === "card") {
            payButton.textContent = "Confirm Demo Payment";
        } else if (method === "bank") {
            payButton.textContent = "Record Bank Transfer Selection";
        } else {
            payButton.textContent = "Confirm Counter Payment";
        }
    }

    showMessage("", "");
}

// Save the updated booking
function updateSavedBooking(booking) {
    var bookings = [];

    try {
        bookings = JSON.parse(
            localStorage.getItem("lankaMoveBookings") || "[]"
        );
    } catch (error) {
        bookings = [];
    }

    if (!Array.isArray(bookings)) {
        bookings = [];
    }

    var found = false;

    for (var i = 0; i < bookings.length; i++) {
        if (
            bookings[i].reference &&
            bookings[i].reference === booking.reference
        ) {
            bookings[i] = booking;
            found = true;
            break;
        }
    }

    // Add the booking if it was not saved previously.
    if (!found) {
        bookings.push(booking);
    }

    localStorage.setItem(
        "lankaMoveBookings",
        JSON.stringify(bookings)
    );

    sessionStorage.setItem(
        "currentBooking",
        JSON.stringify(booking)
    );
}

// Show the confirmation screen
function showPaymentConfirmation(title, message, reference) {
    var paymentLayout = document.querySelector(".payment-layout");
    var pageHeading = document.querySelector(".page-heading");
    var successSection = document.getElementById("paymentSuccess");

    setText("successTitle", title);
    setText("successMessage", message);
    setText("successReference", reference || "Not available");

    if (paymentLayout) {
        paymentLayout.hidden = true;
    }

    if (pageHeading) {
        pageHeading.hidden = true;
    }

    if (successSection) {
        successSection.hidden = false;
        successSection.scrollIntoView({ behavior: "smooth" });
    }
}

// Process the selected demo payment method
function processPayment(event) {
    event.preventDefault();

    if (!currentBooking) {
        showMessage("Please book a journey before making a payment.", "error");
        return;
    }

    if (String(currentBooking.paymentStatus).toLowerCase() === "paid") {
        showMessage("This booking has already been paid.", "error");
        return;
    }

    var terms = document.getElementById("agreeTerms");

    if (!terms || !terms.checked) {
        showMessage("Please confirm that your journey details are correct.", "error");
        return;
    }

    var selectedMethod = document.querySelector(
        'input[name="paymentMethod"]:checked'
    );

    if (!selectedMethod) {
        showMessage("Please select a payment method.", "error");
        return;
    }

    var method = selectedMethod.value;
    var title = "";
    var message = "";

    if (method === "card") {
        var name = document.getElementById("cardName").value.trim();
        var number = document.getElementById("cardNumber").value.trim();
        var expiry = document.getElementById("expiryDate").value.trim();
        var cvv = document.getElementById("cvv").value.trim();

        if (!name || !number || !expiry || !cvv) {
            showMessage("Please complete all demo card fields.", "error");
            return;
        }

        // This is only a coursework simulation.
        // Never enter or store real card details here.
        currentBooking.paymentStatus = "Paid";
        currentBooking.bookingStatus = "Confirmed";
        currentBooking.paymentMethod = "Demo Card";

        title = "Demo Payment Successful!";
        message =
            "Your coursework demo payment has been recorded. " +
            "No real money was charged.";
    } else if (method === "bank") {
        currentBooking.paymentStatus = "Pending Verification";
        currentBooking.bookingStatus = "Awaiting Payment Verification";
        currentBooking.paymentMethod = "Bank Transfer";

        title = "Bank Transfer Selected";
        message =
            "Your booking has been saved as awaiting payment verification. " +
            "No actual bank transfer was made.";
    } else if (method === "counter") {
        currentBooking.paymentStatus = "Unpaid";
        currentBooking.bookingStatus = "Confirmed - Payment Due";
        currentBooking.paymentMethod = "Pay at Counter";

        title = "Counter Payment Selected";
        message =
            "Your booking details have been saved. " +
            "Payment is still due at the counter.";
    } else {
        showMessage("Please select a valid payment method.", "error");
        return;
    }

    try {
        updateSavedBooking(currentBooking);

        showPaymentConfirmation(
            title,
            message,
            currentBooking.reference
        );
    } catch (error) {
        showMessage(
            "Unable to save the booking. Please try again.",
            "error"
        );
    }
}

// Set the footer year
function setCurrentYear() {
    var year = document.getElementById("currentYear");

    if (year) {
        year.textContent = new Date().getFullYear();
    }
}

// Start the payment page
function startPaymentPage() {
    setCurrentYear();
    loadCurrentBooking();
    displayBookingDetails();
    changePaymentMethod();

    var paymentForm = document.getElementById("paymentForm");

    if (paymentForm) {
        paymentForm.addEventListener("submit", processPayment);
    }

    var methods = document.querySelectorAll(
        'input[name="paymentMethod"]'
    );

    for (var i = 0; i < methods.length; i++) {
        methods[i].addEventListener("change", changePaymentMethod);
    }
}

startPaymentPage();

