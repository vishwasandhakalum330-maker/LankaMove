
/* ==========================================
   LANKAMOVE TRANSPORT - ADMIN DASHBOARD
   Dashboard interactions and animations
   ========================================== */

document.addEventListener("DOMContentLoaded", function () {

    // 1. Display current date and year
    const currentDate = document.getElementById("currentDate");
    const currentYear = document.getElementById("currentYear");

    if (currentDate) {
        currentDate.textContent = new Date().toLocaleDateString("en-GB", {
            weekday: "long",
            day: "numeric",
            month: "short",
            year: "numeric"
        });
    }

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }


    // 2. Animate dashboard statistics
    const counters = document.querySelectorAll(".stat-card h2");

    counters.forEach(function (counter) {

        const target = Number(counter.textContent.replace(/,/g, ""));

        if (!Number.isFinite(target)) {
            return;
        }

        const duration = 1200;
        const startTime = performance.now();

        function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            // Smooth ease-out animation
            const easedProgress = 1 - Math.pow(1 - progress, 3);
            const currentValue = Math.floor(target * easedProgress);

            counter.textContent = currentValue.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        }

        requestAnimationFrame(updateCounter);
    });


    // 3. Create bookings chart
    const chartCanvas = document.getElementById("bookingChart");

    if (chartCanvas && typeof Chart !== "undefined") {

        const bookingChart = new Chart(chartCanvas, {
            type: "bar",

            data: {
                labels: [
                    "05 Oct",
                    "06 Oct",
                    "07 Oct",
                    "08 Oct",
                    "09 Oct",
                    "10 Oct",
                    "11 Oct"
                ],

                datasets: [{
                    label: "Bookings",
                    data: [85, 112, 98, 145, 126, 170, 195],

                    backgroundColor: [
                        "#8dbbff",
                        "#6da7fa",
                        "#438cf5",
                        "#287cf0",
                        "#438cf5",
                        "#287cf0",
                        "#1557a6"
                    ],

                    borderRadius: 6,
                    borderSkipped: false,
                    maxBarThickness: 32
                }]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,

                animation: {
                    duration: 1200,
                    easing: "easeOutQuart"
                },

                plugins: {
                    legend: {
                        display: false
                    },

                    tooltip: {
                        backgroundColor: "#102b4e",
                        padding: 12,
                        cornerRadius: 8,
                        displayColors: false,

                        callbacks: {
                            label: function (context) {
                                return context.parsed.y + " bookings";
                            }
                        }
                    }
                },

                scales: {
                    y: {
                        beginAtZero: true,

                        grid: {
                            color: "#edf2f8",
                            drawBorder: false
                        },

                        ticks: {
                            color: "#718096",
                            precision: 0
                        }
                    },

                    x: {
                        grid: {
                            display: false
                        },

                        ticks: {
                            color: "#718096"
                        }
                    }
                }
            }
        });

        // Change chart when selecting a period
        const chartPeriod = document.getElementById("chartPeriod");

        if (chartPeriod) {
            chartPeriod.addEventListener("change", function () {

                if (this.value === "30") {
                    bookingChart.data.labels = [
                        "Week 1",
                        "Week 2",
                        "Week 3",
                        "Week 4"
                    ];

                    bookingChart.data.datasets[0].data = [
                        420, 510, 465, 590
                    ];
                } else {
                    bookingChart.data.labels = [
                        "05 Oct",
                        "06 Oct",
                        "07 Oct",
                        "08 Oct",
                        "09 Oct",
                        "10 Oct",
                        "11 Oct"
                    ];

                    bookingChart.data.datasets[0].data = [
                        85, 112, 98, 145, 126, 170, 195
                    ];
                }

                bookingChart.update();
            });
        }
    }


    // 4. Search the recent bookings table
    const searchInput = document.getElementById("dashboardSearch");
    const bookingsTable = document.getElementById("bookingsTable");
    const noResults = document.getElementById("noResults");

    if (searchInput && bookingsTable) {

        const bookingRows = bookingsTable.querySelectorAll("tbody tr");

        searchInput.addEventListener("input", function () {

            const searchText = this.value.trim().toLowerCase();
            let visibleRows = 0;

            bookingRows.forEach(function (row) {

                const rowText = row.textContent.toLowerCase();
                const matches = rowText.includes(searchText);

                row.style.display = matches ? "" : "none";

                if (matches) {
                    visibleRows++;
                }
            });

            if (noResults) {
                noResults.hidden = visibleRows !== 0;
            }
        });
    }


    // 5. Highlight the selected sidebar link
    const menuLinks = document.querySelectorAll(".menu-link");

    menuLinks.forEach(function (link) {

        link.addEventListener("click", function () {

            menuLinks.forEach(function (item) {
                item.classList.remove("active");
            });

            this.classList.add("active");
        });
    });


    // 6. Notification button demonstration
    const notificationButton =
        document.querySelector(".icon-button");

    if (notificationButton) {
        notificationButton.addEventListener("click", function () {
            alert("You are viewing the LankaMove admin dashboard demo.");
        });
    }


    // 7. Add a small animation to dashboard cards when hovered
    const statCards = document.querySelectorAll(".stat-card");

    statCards.forEach(function (card) {

        card.addEventListener("mouseenter", function () {
            this.style.zIndex = "2";
        });

        card.addEventListener("mouseleave", function () {
            this.style.zIndex = "1";
        });
    });


    // 8. Display a welcome message in the browser console
    console.log("LankaMove Transport Admin Dashboard loaded successfully.");

});