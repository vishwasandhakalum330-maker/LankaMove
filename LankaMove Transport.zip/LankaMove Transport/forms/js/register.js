
document.addEventListener("DOMContentLoaded", function () {

    const registerForm =
        document.getElementById("registerForm");

    const customerId =
        document.getElementById("customerId");

    const customerName =
        document.getElementById("customerName");

    const email =
        document.getElementById("email");

    const phone =
        document.getElementById("phone");

    const address =
        document.getElementById("address");

    const password =
        document.getElementById("password");

    const confirmPassword =
        document.getElementById("confirmPassword");

    const terms =
        document.getElementById("terms");


    const customerIdError =
        document.getElementById("customerIdError");

    const customerNameError =
        document.getElementById("customerNameError");

    const emailError =
        document.getElementById("emailError");

    const phoneError =
        document.getElementById("phoneError");

    const addressError =
        document.getElementById("addressError");

    const passwordError =
        document.getElementById("passwordError");

    const confirmPasswordError =
        document.getElementById("confirmPasswordError");


    const passwordButton =
        document.getElementById("passwordButton");

    const confirmPasswordButton =
        document.getElementById("confirmPasswordButton");

    const registerButton =
        document.getElementById("registerButton");

    const formMessage =
        document.getElementById("formMessage");



    if (passwordButton && password) {

        passwordButton.addEventListener(
            "click",
            function () {

                if (password.type === "password") {

                    password.type = "text";

                    passwordButton.textContent = "Hide";

                    passwordButton.setAttribute(
                        "aria-label",
                        "Hide password"
                    );

                } else {

                    password.type = "password";

                    passwordButton.textContent = "Show";

                    passwordButton.setAttribute(
                        "aria-label",
                        "Show password"
                    );
                }
            }
        );
    }


    // ==========================================
    // Show / Hide Confirm Password
    // ==========================================

    if (confirmPasswordButton && confirmPassword) {

        confirmPasswordButton.addEventListener(
            "click",
            function () {

                if (confirmPassword.type === "password") {

                    confirmPassword.type = "text";

                    confirmPasswordButton.textContent =
                        "Hide";

                    confirmPasswordButton.setAttribute(
                        "aria-label",
                        "Hide password"
                    );

                } else {

                    confirmPassword.type = "password";

                    confirmPasswordButton.textContent =
                        "Show";

                    confirmPasswordButton.setAttribute(
                        "aria-label",
                        "Show password"
                    );
                }
            }
        );
    }


   

    function showError(input, errorElement, message) {

        const formGroup =
            input.closest(".form-group");

        if (formGroup) {

            formGroup.classList.remove("success");
            formGroup.classList.add("error");
        }

        errorElement.textContent = message;
    }


   

    function showSuccess(input, errorElement) {

        const formGroup =
            input.closest(".form-group");

        if (formGroup) {

            formGroup.classList.remove("error");
            formGroup.classList.add("success");
        }

        errorElement.textContent = "";
    }


    function clearValidation(input, errorElement) {

        const formGroup =
            input.closest(".form-group");

        if (formGroup) {

            formGroup.classList.remove("error");
            formGroup.classList.remove("success");
        }

        errorElement.textContent = "";
    }


   
    // Customer ID Validation
    

    function validateCustomerId() {

        const value =
            customerId.value.trim();

        if (value === "") {

            showError(
                customerId,
                customerIdError,
                "Please enter your customer ID."
            );

            return false;
        }

        if (value.length < 3) {

            showError(
                customerId,
                customerIdError,
                "Customer ID must contain at least 3 characters."
            );

            return false;
        }

        showSuccess(
            customerId,
            customerIdError
        );

        return true;
    }


    
    // Customer Name Validation
    
    function validateCustomerName() {

        const value =
            customerName.value.trim();

        const namePattern =
            /^[A-Za-z\s]+$/;

        if (value === "") {

            showError(
                customerName,
                customerNameError,
                "Please enter your name."
            );

            return false;
        }

        if (value.length < 3) {

            showError(
                customerName,
                customerNameError,
                "Name must contain at least 3 characters."
            );

            return false;
        }

        if (!namePattern.test(value)) {

            showError(
                customerName,
                customerNameError,
                "Name can contain letters and spaces only."
            );

            return false;
        }

        showSuccess(
            customerName,
            customerNameError
        );

        return true;
    }


    // ==========================================
    // Email Validation
    // ==========================================

    function validateEmail() {

        const value =
            email.value.trim();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (value === "") {

            showError(
                email,
                emailError,
                "Please enter your email address."
            );

            return false;
        }

        if (!emailPattern.test(value)) {

            showError(
                email,
                emailError,
                "Please enter a valid email address."
            );

            return false;
        }

        showSuccess(
            email,
            emailError
        );

        return true;
    }


    // ==========================================
    // Phone Number Validation
    // ==========================================

    function validatePhone() {

        const value =
            phone.value.trim();

        /*
         * Sri Lankan mobile number:
         * Example: 0771234567
         */

        const phonePattern =
            /^(?:\+94|0)7[0-9]{8}$/;

        if (value === "") {

            showError(
                phone,
                phoneError,
                "Please enter your phone number."
            );

            return false;
        }

        if (!phonePattern.test(value)) {

            showError(
                phone,
                phoneError,
                "Please enter a valid Sri Lankan phone number."
            );

            return false;
        }

        showSuccess(
            phone,
            phoneError
        );

        return true;
    }


    // ==========================================
    // Address Validation
    // ==========================================

    function validateAddress() {

        const value =
            address.value.trim();

        if (value === "") {

            showError(
                address,
                addressError,
                "Please enter your address."
            );

            return false;
        }

        if (value.length < 5) {

            showError(
                address,
                addressError,
                "Please enter a complete address."
            );

            return false;
        }

        showSuccess(
            address,
            addressError
        );

        return true;
    }


    // ==========================================
    // Password Validation
    // ==========================================

    function validatePassword() {

        const value =
            password.value;

        if (value === "") {

            showError(
                password,
                passwordError,
                "Please create a password."
            );

            return false;
        }

        if (value.length < 6) {

            showError(
                password,
                passwordError,
                "Password must contain at least 6 characters."
            );

            return false;
        }

        showSuccess(
            password,
            passwordError
        );

        return true;
    }


    // ==========================================
    // Confirm Password Validation
    // ==========================================

    function validateConfirmPassword() {

        const value =
            confirmPassword.value;

        if (value === "") {

            showError(
                confirmPassword,
                confirmPasswordError,
                "Please confirm your password."
            );

            return false;
        }

        if (value !== password.value) {

            showError(
                confirmPassword,
                confirmPasswordError,
                "Passwords do not match."
            );

            return false;
        }

        showSuccess(
            confirmPassword,
            confirmPasswordError
        );

        return true;
    }


    // ==========================================
    // Customer ID Input
    // ==========================================

    if (customerId) {

        customerId.addEventListener(
            "input",
            function () {

                clearValidation(
                    customerId,
                    customerIdError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        customerId.addEventListener(
            "blur",
            function () {

                if (customerId.value.trim() !== "") {
                    validateCustomerId();
                }
            }
        );
    }


    // ==========================================
    // Name Input
    // ==========================================

    if (customerName) {

        customerName.addEventListener(
            "input",
            function () {

                clearValidation(
                    customerName,
                    customerNameError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        customerName.addEventListener(
            "blur",
            function () {

                if (customerName.value.trim() !== "") {
                    validateCustomerName();
                }
            }
        );
    }


    // ==========================================
    // Email Input
    // ==========================================

    if (email) {

        email.addEventListener(
            "input",
            function () {

                clearValidation(
                    email,
                    emailError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        email.addEventListener(
            "blur",
            function () {

                if (email.value.trim() !== "") {
                    validateEmail();
                }
            }
        );
    }


    // ==========================================
    // Phone Input
    // ==========================================

    if (phone) {

        phone.addEventListener(
            "input",
            function () {

                clearValidation(
                    phone,
                    phoneError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        phone.addEventListener(
            "blur",
            function () {

                if (phone.value.trim() !== "") {
                    validatePhone();
                }
            }
        );
    }


    // ==========================================
    // Address Input
    // ==========================================

    if (address) {

        address.addEventListener(
            "input",
            function () {

                clearValidation(
                    address,
                    addressError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        address.addEventListener(
            "blur",
            function () {

                if (address.value.trim() !== "") {
                    validateAddress();
                }
            }
        );
    }


    // ==========================================
    // Password Input
    // ==========================================

    if (password) {

        password.addEventListener(
            "input",
            function () {

                clearValidation(
                    password,
                    passwordError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        password.addEventListener(
            "blur",
            function () {

                if (password.value !== "") {
                    validatePassword();
                }
            }
        );
    }


    // ==========================================
    // Confirm Password Input
    // ==========================================

    if (confirmPassword) {

        confirmPassword.addEventListener(
            "input",
            function () {

                clearValidation(
                    confirmPassword,
                    confirmPasswordError
                );

                formMessage.textContent = "";
                formMessage.className =
                    "form-message";
            }
        );

        confirmPassword.addEventListener(
            "blur",
            function () {

                if (confirmPassword.value !== "") {
                    validateConfirmPassword();
                }
            }
        );
    }


    // ==========================================
    // Registration Form
    // ==========================================

    if (registerForm) {

        registerForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const validCustomerId =
                    validateCustomerId();

                const validCustomerName =
                    validateCustomerName();

                const validEmail =
                    validateEmail();

                const validPhone =
                    validatePhone();

                const validAddress =
                    validateAddress();

                const validPassword =
                    validatePassword();

                const validConfirmPassword =
                    validateConfirmPassword();


                // Check Terms

                if (!terms.checked) {

                    formMessage.textContent =
                        "Please accept the Terms & Conditions.";

                    formMessage.className =
                        "form-message error";

                    return;
                }


                // Check all fields

                if (
                    !validCustomerId ||
                    !validCustomerName ||
                    !validEmail ||
                    !validPhone ||
                    !validAddress ||
                    !validPassword ||
                    !validConfirmPassword
                ) {

                    formMessage.textContent =
                        "Please correct the errors above.";

                    formMessage.className =
                        "form-message error";

                    return;
                }


                // Start loading

                registerButton.classList.add("loading");

                formMessage.textContent = "";

                formMessage.className =
                    "form-message";


                /*
                 * Temporary registration process.
                 *
                 * This will later be connected
                 * to the real database.
                 */

                setTimeout(function () {

                    registerButton.classList.remove(
                        "loading"
                    );


                    formMessage.textContent =
                        "Account created successfully!";

                    formMessage.className =
                        "form-message success";


                    // Clear form

                    registerForm.reset();


                }, 1500);

            }
        );
    }

});

