```javascript
// ==========================================
// LankaMove
// Login Page JavaScript
// ==========================================


document.addEventListener("DOMContentLoaded", function () {


    // --------------------------------------
    // Get Form Elements
    // --------------------------------------

    const loginForm = document.getElementById("loginForm");

    const email = document.getElementById("email");
    const password = document.getElementById("password");

    const emailError = document.getElementById("emailError");
    const passwordError = document.getElementById("passwordError");

    const passwordButton =
        document.getElementById("passwordButton");

    const loginButton =
        document.getElementById("loginButton");

    const formMessage =
        document.getElementById("formMessage");


    // --------------------------------------
    // Show / Hide Password
    // --------------------------------------

    if (passwordButton && password) {

        passwordButton.addEventListener("click", function () {

            if (password.type === "password") {

                password.type = "text";

                passwordButton.textContent = "Hide";

                passwordButton.setAttribute(
                    "aria-label",
                    "Hide password"
                );

            } else {

                password.type = "password";

                passwordButton.textContent = "Show";

                passwordButton.setAttribute(
                    "aria-label",
                    "Show password"
                );
            }

        });
    }


    // --------------------------------------
    // Email Validation
    // --------------------------------------

    function validateEmail() {

        const value = email.value.trim();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (value === "") {

            showError(
                email,
                emailError,
                "Please enter your email address."
            );

            return false;
        }


        if (!emailPattern.test(value)) {

            showError(
                email,
                emailError,
                "Please enter a valid email address."
            );

            return false;
        }


        showSuccess(email, emailError);

        return true;
    }


    // --------------------------------------
    // Password Validation
    // --------------------------------------

    function validatePassword() {

        const value = password.value;


        if (value === "") {

            showError(
                password,
                passwordError,
                "Please enter your password."
            );

            return false;
        }


        if (value.length < 6) {

            showError(
                password,
                passwordError,
                "Password must contain at least 6 characters."
            );

            return false;
        }


        showSuccess(password, passwordError);

        return true;
    }


    // --------------------------------------
    // Show Error
    // --------------------------------------

    function showError(input, errorElement, message) {

        const formGroup =
            input.closest(".form-group");


        if (formGroup) {
            formGroup.classList.remove("success");
            formGroup.classList.add("error");
        }


        errorElement.textContent = message;
    }


    // --------------------------------------
    // Show Success
    // --------------------------------------

    function showSuccess(input, errorElement) {

        const formGroup =
            input.closest(".form-group");


        if (formGroup) {
            formGroup.classList.remove("error");
            formGroup.classList.add("success");
        }


        errorElement.textContent = "";
    }


    // --------------------------------------
    // Remove Validation
    // --------------------------------------

    function clearValidation(input, errorElement) {

        const formGroup =
            input.closest(".form-group");


        if (formGroup) {

            formGroup.classList.remove("error");
            formGroup.classList.remove("success");
        }


        errorElement.textContent = "";
    }


    // --------------------------------------
    // Email Input
    // --------------------------------------

    if (email) {

        email.addEventListener("input", function () {

            clearValidation(email, emailError);

            formMessage.textContent = "";
            formMessage.className = "form-message";

        });


        email.addEventListener("blur", function () {

            if (email.value.trim() !== "") {
                validateEmail();
            }

        });
    }


    // --------------------------------------
    // Password Input
    // --------------------------------------

    if (password) {

        password.addEventListener("input", function () {

            clearValidation(
                password,
                passwordError
            );

            formMessage.textContent = "";
            formMessage.className = "form-message";

        });


        password.addEventListener("blur", function () {

            if (password.value !== "") {
                validatePassword();
            }

        });
    }


    // --------------------------------------
    // Login Form
    // --------------------------------------

    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                // Validate fields

                const validEmail =
                    validateEmail();

                const validPassword =
                    validatePassword();


                // Stop if validation fails

                if (!validEmail || !validPassword) {

                    formMessage.textContent =
                        "Please correct the errors above.";

                    formMessage.className =
                        "form-message error";

                    return;
                }


                // Start loading animation

                loginButton.classList.add("loading");


                // Clear previous message

                formMessage.textContent = "";

                formMessage.className =
                    "form-message";


                /*
                 * Temporary login process.
                 *
                 * This will later be replaced with
                 * the real database login system.
                 */

                setTimeout(function () {

                    loginButton.classList.remove("loading");


                    formMessage.textContent =
                        "Login details are valid. Connecting...";

                    formMessage.className =
                        "form-message success";


                }, 1200);

            }
        );
    }

});
```
