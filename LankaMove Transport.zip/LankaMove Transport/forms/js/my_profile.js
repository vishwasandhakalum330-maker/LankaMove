
const profileForm = document.getElementById("profileForm");
const editButton = document.getElementById("editButton");
const cancelButton = document.getElementById("cancelButton");
const saveButton = document.getElementById("saveButton");
const formActions = document.getElementById("formActions");
const profileMessage = document.getElementById("profileMessage");

// Profile information fields
const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const dateOfBirth = document.getElementById("dateOfBirth");
const address = document.getElementById("address");

// Profile display elements
const displayName = document.getElementById("displayName");
const displayEmail = document.getElementById("displayEmail");
const profileAvatar = document.getElementById("profileAvatar");
const welcomeName = document.getElementById("welcomeName");

// Profile completion elements
const completionPercent = document.getElementById("completionPercent");
const completionLabel = document.getElementById("completionLabel");
const progressFill = document.getElementById("progressFill");
const progressTrack = document.getElementById("progressTrack");

// Booking and date elements
const totalBookings = document.getElementById("totalBookings");
const currentDate = document.getElementById("currentDate");
const currentYear = document.getElementById("currentYear");

// Local storage keys
const profileStorageKey = "lankaMoveCustomerProfile";
const bookingsStorageKey = "lankaMoveBookings";

// Keep a copy of the original profile details
let originalProfile = {};

// ==========================================
// Get the profile details
// ==========================================

function getProfileData() {
    return {
        fullName: fullName.value.trim(),
        email: email.value.trim(),
        phone: phone.value.trim(),
        dateOfBirth: dateOfBirth.value,
        address: address.value.trim()
    };
}

// ==========================================
// Load the saved profile
// ==========================================

function loadProfile() {
    let savedProfile = null;

    try {
        const storedProfile = localStorage.getItem(profileStorageKey);

        if (storedProfile) {
            savedProfile = JSON.parse(storedProfile);
        }
    } catch (error) {
        console.error("Unable to load profile:", error);
    }

    // Use saved information if it exists
    if (savedProfile && typeof savedProfile === "object") {
        fullName.value = savedProfile.fullName || "";
        email.value = savedProfile.email || "";
        phone.value = savedProfile.phone || "";
        dateOfBirth.value = savedProfile.dateOfBirth || "";
        address.value = savedProfile.address || "";
    }

    // Keep the original values for the Cancel button
    originalProfile = getProfileData();

    updateProfileDisplay();
    updateProfileCompletion();
}

// ==========================================
// Update the profile header
// ==========================================

function updateProfileDisplay() {
    const name = fullName.value.trim();
    const emailAddress = email.value.trim();

    displayName.textContent = name || "Customer Name";
    displayEmail.textContent = emailAddress || "No email added";

    welcomeName.textContent = name
        ? name.split(/\s+/)[0]
        : "Traveller";

    // Use the first letter of the customer's name
    profileAvatar.textContent = name
        ? name.charAt(0).toUpperCase()
        : "C";
}

// ==========================================
// Calculate profile completion
// ==========================================

function updateProfileCompletion() {
    const fields = [
        fullName.value.trim(),
        email.value.trim(),
        phone.value.trim(),
        dateOfBirth.value,
        address.value.trim()
    ];

    let completedFields = 0;

    fields.forEach(function (field) {
        if (field !== "") {
            completedFields++;
        }
    });

    const percentage = Math.round(
        (completedFields / fields.length) * 100
    );

    completionPercent.textContent = percentage + "%";
    progressFill.style.width = percentage + "%";

    progressTrack.setAttribute("aria-valuenow", percentage);

    if (percentage === 100) {
        completionLabel.textContent = "Profile complete!";
    } else if (percentage >= 60) {
        completionLabel.textContent = "Almost there";
    } else if (percentage >= 20) {
        completionLabel.textContent = "Good start";
    } else {
        completionLabel.textContent = "Getting started";
    }
}

// ==========================================
// Enable profile editing
// ==========================================

function enableEditing() {
    const fields = [
        fullName,
        email,
        phone,
        dateOfBirth,
        address
    ];

    fields.forEach(function (field) {
        field.disabled = false;
    });

    formActions.hidden = false;
    editButton.hidden = true;

    hideProfileMessage();

    fullName.focus();
}

// ==========================================
// Cancel editing
// ==========================================

function cancelEditing() {
    fullName.value = originalProfile.fullName;
    email.value = originalProfile.email;
    phone.value = originalProfile.phone;
    dateOfBirth.value = originalProfile.dateOfBirth;
    address.value = originalProfile.address;

    setEditingMode(false);

    updateProfileDisplay();
    updateProfileCompletion();

    hideProfileMessage();
}

// ==========================================
// Set editing mode
// ==========================================

function setEditingMode(isEditing) {
    const fields = [
        fullName,
        email,
        phone,
        dateOfBirth,
        address
    ];

    fields.forEach(function (field) {
        field.disabled = !isEditing;
    });

    formActions.hidden = !isEditing;
    editButton.hidden = isEditing;
}

// ==========================================
// Show a message
// ==========================================

function showProfileMessage(message, type) {
    profileMessage.textContent = message;
    profileMessage.className = "profile-message " + type;
}

function hideProfileMessage() {
    profileMessage.textContent = "";
    profileMessage.className = "profile-message";
}

// ==========================================
// Save the profile
// ==========================================

profileForm.addEventListener("submit", function (event) {
    event.preventDefault();

    // Get the entered details
    const profile = getProfileData();

    // Check the full name
    if (profile.fullName.length < 2) {
        showProfileMessage(
            "Please enter your full name.",
            "error"
        );

        fullName.focus();
        return;
    }

    // Check the email address
    if (!email.checkValidity()) {
        showProfileMessage(
            "Please enter a valid email address.",
            "error"
        );

        email.focus();
        return;
    }

    // Check the phone number
    if (!/^[0-9+\-\s()]{7,20}$/.test(profile.phone)) {
        showProfileMessage(
            "Please enter a valid phone number.",
            "error"
        );

        phone.focus();
        return;
    }

    // Check the date of birth
    if (profile.dateOfBirth) {
        const birthDate = new Date(
            profile.dateOfBirth + "T00:00:00"
        );

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (
            Number.isNaN(birthDate.getTime()) ||
            birthDate > today
        ) {
            showProfileMessage(
                "Date of birth cannot be in the future.",
                "error"
            );

            dateOfBirth.focus();
            return;
        }
    }

    // Save the details in the browser
    try {
        localStorage.setItem(
            profileStorageKey,
            JSON.stringify(profile)
        );
    } catch (error) {
        showProfileMessage(
            "Your profile could not be saved in this browser.",
            "error"
        );

        return;
    }

    // Update the saved profile information
    originalProfile = { ...profile };

    updateProfileDisplay();
    updateProfileCompletion();

    setEditingMode(false);

    showProfileMessage(
        "Your profile has been saved successfully!",
        "success"
    );
});

// ==========================================
// Count the customer's bookings
// ==========================================

function updateBookingCount() {
    try {
        const storedBookings = localStorage.getItem(
            bookingsStorageKey
        );

        const bookings = storedBookings
            ? JSON.parse(storedBookings)
            : [];

        if (Array.isArray(bookings)) {
            totalBookings.textContent = bookings.length;
        } else {
            totalBookings.textContent = "0";
        }
    } catch (error) {
        totalBookings.textContent = "0";
    }
}

// ==========================================
// Display the current date and year
// ==========================================

function updateDateAndYear() {
    const today = new Date();

    currentDate.textContent = today.toLocaleDateString(
        "en-US",
        {
            month: "short",
            day: "numeric",
            year: "numeric"
        }
    );

    currentYear.textContent = today.getFullYear();
}

// ==========================================
// Listen for changes while editing
// ==========================================

[
    fullName,
    email,
    phone,
    dateOfBirth,
    address
].forEach(function (field) {
    field.addEventListener("input", function () {
        updateProfileCompletion();
    });
});

// ==========================================
// Button Events
// ==========================================

editButton.addEventListener("click", enableEditing);

cancelButton.addEventListener("click", cancelEditing);

// ==========================================
// Start the Profile Page
// ==========================================

function startProfilePage() {
    loadProfile();
    updateBookingCount();
    updateDateAndYear();

    setEditingMode(false);
}

startProfilePage();

